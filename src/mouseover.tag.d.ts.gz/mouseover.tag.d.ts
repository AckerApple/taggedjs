export declare const mouseOverTag: import("taggedjs").TaggedFunction<({ label, memory, }: {
    label: string;
    memory: {
        counter: number;
    };
}) => import("taggedjs").Tag>;
