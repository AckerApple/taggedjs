export { hmr } from "taggedjs";
export { App } from "./app.tag";
import IsolatedApp from "./isolatedApp";
export { IsolatedApp };
export { app } from './app.function';
