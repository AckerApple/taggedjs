declare const _default: import("taggedjs").TaggedFunction<(routeTag: import("taggedjs").RouteTag) => () => import("taggedjs").Tag>;
export default _default;
