export declare const ADD_ITEM = "ADD_ITEM";
export declare const UPDATE_ITEM = "UPDATE_ITEM";
export declare const REMOVE_ITEM = "REMOVE_ITEM";
export declare const TOGGLE_ITEM = "TOGGLE_ITEM";
export declare const REMOVE_ALL_ITEMS = "REMOVE_ALL_ITEMS";
export declare const TOGGLE_ALL = "TOGGLE_ALL";
export declare const REMOVE_COMPLETED_ITEMS = "REMOVE_COMPLETED_ITEMS";
