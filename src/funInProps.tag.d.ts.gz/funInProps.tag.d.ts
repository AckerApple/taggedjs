declare const _default: import("taggedjs").TaggedFunction<() => (array?: string[], counter?: number, myFunction?: () => number, renderCount?: number, showChild?: boolean, somethingElse?: string, _?: number, addArrayItem?: (x?: string) => void, deleteItem?: (item: string) => string[]) => import("taggedjs").Tag>;
export default _default;
