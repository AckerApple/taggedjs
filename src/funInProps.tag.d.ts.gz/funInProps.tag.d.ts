declare const _default: import("taggedjs").TaggedFunction<() => (counter?: number, myFunction?: () => number, renderCount?: number, showChild?: boolean, somethingElse?: string, _?: number) => import("taggedjs").Tag>;
export default _default;
