export declare const propsDebugMain: import("taggedjs").TaggedFunction<(_?: any) => (propNumber?: number, renderCount?: number, propsJson?: {
    test: number;
    x: string;
}, date?: Date, syncPropNumber?: number, json?: string) => import("taggedjs").Tag>;
