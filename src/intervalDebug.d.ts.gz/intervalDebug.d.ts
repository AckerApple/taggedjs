export declare const intervalTester0: import("taggedjs").TaggedFunction<() => import("taggedjs").Tag>;
export declare const intervalTester1: import("taggedjs").TaggedFunction<() => import("taggedjs").Tag>;
