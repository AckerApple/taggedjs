export declare const propsDebugMain: import("taggedjs").TaggedFunction<(_?: any) => (syncPropNumber?: number, propNumber?: number, renderCount?: number, propsJson?: {
    test: number;
    x: string;
}, date?: Date, json?: string) => import("taggedjs").Tag>;
