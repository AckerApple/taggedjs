export declare const innerHtmlTest: import("taggedjs").TaggedFunction<(_props: unknown, b: number) => import("taggedjs").Tag>;
export declare const innerHtmlPropsTest: import("taggedjs").TaggedFunction<(x: number) => import("taggedjs").Tag>;
