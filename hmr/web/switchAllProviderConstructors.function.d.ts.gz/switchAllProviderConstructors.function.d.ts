/**
 * @typedef {import("taggedjs").TagSupport} TagSupport
 */
/**
 *
 * @param {TagSupport} tagSupport
 * @param {Provider} provider
 */
export declare function switchAllProviderConstructors(tagSupport: any, provider: any): void;
