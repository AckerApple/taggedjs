import { InsertBefore } from '../interpolations/Clones.type';
import { TagGlobal } from './TemplaterResult.class';
export declare function setTagPlaceholder(global: TagGlobal): Text;
export declare function swapInsertBefore(insertBefore: InsertBefore): Text;
