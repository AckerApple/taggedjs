import { TagSubject } from '../../subject.types';
import { TagSupport } from '../TagSupport.class';
export declare function renderSubjectComponent(subject: TagSubject, reSupport: TagSupport, ownerSupport: TagSupport): TagSupport;
