import { TagSupport } from '../TagSupport.class';
import { TagSubject } from '../../subject.types';
export declare function renderTagOnly(newTagSupport: TagSupport, lastSupport: TagSupport | undefined, subject: TagSubject, ownerSupport?: TagSupport): TagSupport;
