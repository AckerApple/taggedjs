import { TagSupport } from '../TagSupport.class';
/** Main function used by all other callers to render/update display of a tag component */
export declare function renderTagSupport(tagSupport: TagSupport, // must be latest/newest state render
renderUp: boolean): TagSupport;
