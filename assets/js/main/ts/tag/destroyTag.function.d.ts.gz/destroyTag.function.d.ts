import { TagSupport } from './TagSupport.class';
export declare function destroyTagMemory(oldTagSupport: TagSupport): void;
export declare function destroyTagSupportPast(oldTagSupport: TagSupport): void;
