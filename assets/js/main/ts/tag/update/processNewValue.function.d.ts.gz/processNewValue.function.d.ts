import { TagSupport } from '../TagSupport.class';
import { InterpolateSubject, TemplateValue } from './processFirstSubject.utils';
export declare function processNewValue(value: TemplateValue, ownerSupport: TagSupport): InterpolateSubject;
