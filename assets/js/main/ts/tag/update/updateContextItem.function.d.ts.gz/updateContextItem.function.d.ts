import { TemplateValue } from './processFirstSubject.utils';
import { Context } from '../Tag.class';
export declare function updateContextItem(context: Context, variableName: string, value: TemplateValue): void;
