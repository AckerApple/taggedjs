import { Tag } from "./Tag.class";
import { TagSupport } from "./TagSupport.class";
export declare function isLikeTags(tagSupport0: TagSupport | Tag, // new
tagSupport1: TagSupport): Boolean;
export declare function isLikeValueSets(values0: any[], values1: any[]): boolean;
