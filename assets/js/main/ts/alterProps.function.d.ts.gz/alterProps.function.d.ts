import { TagSupport } from './tag/TagSupport.class';
export declare function alterProps(props: unknown, ownerSupport: TagSupport): any;
export declare function callbackPropOwner(toCall: Function, callWith: any, ownerSupport: TagSupport): any;
