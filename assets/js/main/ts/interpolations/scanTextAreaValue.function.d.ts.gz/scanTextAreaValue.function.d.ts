import { Context } from '../tag/Tag.class';
import { TagSupport } from '../tag/TagSupport.class';
export declare function scanTextAreaValue(textarea: HTMLTextAreaElement, context: Context, ownerSupport: TagSupport): void;
