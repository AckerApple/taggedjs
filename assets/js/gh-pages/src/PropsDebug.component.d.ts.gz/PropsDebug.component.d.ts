export declare const propsDebugMain: ((_?: any) => (propNumber?: any, renderCount?: any, propsJson?: any, date?: any, syncPropNumber?: any, json?: any) => import("taggedjs").Tag) & {
    original: Function;
};
