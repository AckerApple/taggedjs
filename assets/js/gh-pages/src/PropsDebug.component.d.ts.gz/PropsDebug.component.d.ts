export declare const propsDebugMain: ((_?: string) => (propNumber?: number, renderCount?: number, propsJson?: {
    test: number;
    x: string;
}, date?: Date, syncPropNumber?: number, json?: string) => import("taggedjs").Tag) & {
    original: Function;
};
