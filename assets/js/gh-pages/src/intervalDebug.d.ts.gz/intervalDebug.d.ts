export declare const intervalTester0: (() => import("taggedjs").Tag) & {
    original: Function;
};
export declare const intervalTester1: (() => import("taggedjs").Tag) & {
    original: Function;
};
