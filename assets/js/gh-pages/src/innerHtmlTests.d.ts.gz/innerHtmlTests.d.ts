import { Tag } from "taggedjs";
export declare const innerHtmlTest: ((_props: unknown, b: number) => Tag) & {
    original: Function;
};
export declare const innerHtmlPropsTest: ((x: number) => Tag) & {
    original: Function;
};
