export declare const watchTesting: (() => (stateNum?: number, stateNumChangeCount?: number, _?: any, slowChangeCount?: number, watchPropNumSlow?: number | undefined, subjectChangeCount?: number, watchPropNumSubject?: import("taggedjs").Subject<number>, truthChange?: boolean, truthChangeCount?: number, watchTruth?: number | undefined, truthSubChangeCount?: number, watchTruthAsSub?: import("taggedjs").Subject<number | "undefined">) => import("taggedjs").Tag) & {
    original: Function;
};
