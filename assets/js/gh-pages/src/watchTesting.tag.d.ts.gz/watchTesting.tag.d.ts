export declare const watchTesting: (() => (stateNum?: any, stateNumChangeCount?: any, _?: any, slowChangeCount?: any, watchPropNumSlow?: any, subjectChangeCount?: any, watchPropNumSubject?: any, truthChange?: any, truthChangeCount?: any, watchTruth?: any, truthSubChangeCount?: any, watchTruthAsSub?: any) => import("taggedjs").Tag) & {
    original: Function;
};
