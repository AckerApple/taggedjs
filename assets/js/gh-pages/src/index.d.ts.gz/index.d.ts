export { App } from "./app.tag";
import IsolatedApp from "./isolatedApp";
export { IsolatedApp };
export { hmr } from "taggedjs";
export { app } from './app.function';
