export { App } from "./app.tag";
export { IsolatedApp } from "./isolatedApp";
export { hmr } from "taggedjs";
export { app } from './app.function';
